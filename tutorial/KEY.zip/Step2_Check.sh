#!/bin/bash

# ATTENTION: Use this script in any shell: bash, csh, tcsh, or zsh.
# Windows Cygwin users can run this too!
#
# *** What this is checking for ***
#
# in INERTCLDS:
#
# 07180.atmos_diurn.nc (2.1)
# 07180.fixed.nc (2.1)
# 07180.atmos_average.nc (2.1) with rho, zfull (2.4)
# 07180.atmos_average_pstd.nc (2.2) with msf (2.3)
# 07180.atmos_average_zstd.nc (2.5) with d_dz_ucomp d_dz_vcomp (2.8)
# 07180.atmos_diurn_T.nc (2.6) with ts ps temp (2.6)
# 07180.atmos_diurn_T_pstd.nc (2.6) with ts ps temp (2.6)
# 07180.atmos_daily_lpf.nc (2.7) with ps ts and Low-pass filter cut-off period  (2) (2.7)
# 07180.atmos_daily.nc (2.1) with dst_mass_col ice_mass_col vap_mass_col (2.9)
# 
# in ACTIVECLDS:
# 
# 07180.atmos_average.nc (2.1b)
# 07180.atmos_daily.nc (2.1b)
# 07180.atmos_diurn.nc (2.1b)
# 07180.fixed.nc (2.1b)
# 07180.atmos_average_pstd.nc (2.2b)
# 07180.atmos_average_zstd.nc (2.5b)

echo -e "\n\033[1;36m********************** Begin check **********************\033[0m\n"

mi=0
ma=0

# ===================================================================================
# Confirm directory hosting CAP_Tutorial/ so Step2_Check.sh 
#   runs successfully
# ===================================================================================

echo -e "\n\033[0;36m>>> Your current path is:\n\n\033[0m$PWD\033[0;36m\n\n>>> Please type the path to the directory containing CAP_Tutorial,\n     i.e. /Users/username:\033[0m\n"

read pth

echo -e "\n\033[0;36m...Looking for CAP_Tutorial in ${pth}/... \033[0m\n"

if [ -d "${pth}/CAP_Tutorial" ]; then
    cd $pth
    echo -e "\033[1;32mConfirmed! CAP_Tutorial is in ${pth}/ \033[0m"
else
    echo -e "\033[1;31m *** ERROR: ${pth}/ does NOT contain CAP_Tutorial/ *** \033[0m\n"
    exit 1
fi


echo -e "\n\033[0;36mLooking for incorrect files/variables created in Step 2 of CAP_Tutorial...\033[0m\n"


# ===================================================================================
# cd to INERTCLDS
# ===================================================================================
echo -e "\033[0;36mfor INERTCLDS:\033[0m\n"

cd $pth/CAP_Tutorial/INERTCLDS

# ===================================================================================
# 1.1 & 2.1 Make sure all files are present in INERTCLDS
# ===================================================================================

ls > ls.out

inertfiles="07180.atmos_diurn.nc 07180.fixed.nc fort.11_0719 fort.11_0720 fort.11_0721 fort.11_0722 fort.11_0723"

for fname in $inertfiles; do
    if grep -q $fname ls.out; then
        let mi=mi+0
        #echo -e "$fname exists"
    else
        echo -e "\033[1;31m MISSING $fname, redo Steps 1.1 and 2.1\033[0m"
        let mi=mi+1
    fi
done

# ===================================================================================
# 2.2 & 2.3 Make sure msf is in atmos_average_pstd
# ===================================================================================

if grep -q "07180.atmos_average_pstd.nc" ls.out; then
    MarsPlot.py -i 07180.atmos_average_pstd.nc > inspect.out

    varlist="msf"

    for vname in $varlist; do
        if grep -q $vname inspect.out; then
            let mi=mi+0
            #echo -e "$vname exists"
        else
            echo -e "\033[1;31m MISSING $vname in 07180.atmos_average_pstd.nc, redo Step 2.3\033[0m"
            let mi=mi+1
        fi
    done
    rm inspect.out
else
    echo -e "\033[1;31m MISSING 07180.atmos_average_pstd.nc, redo Step 2.2\033[0m"
    let mi=mi+1
fi


# ===================================================================================
# 2.1 & 2.4 Make sure rho and zfull are in atmos_average
# ===================================================================================

if grep -q "07180.atmos_average.nc" ls.out; then
    MarsPlot.py -i 07180.atmos_average.nc > inspect.out

    varlist="rho zfull"

    for vname in $varlist; do
        if grep -q $vname inspect.out; then
            let mi=mi+0
            #echo -e "$vname exists"
        else
            echo -e "\033[1;31m MISSING $vname in 07180.atmos_average.nc, redo Step 2.4\033[0m"
            let mi=mi+1
        fi
    done
    rm inspect.out
else
    echo -e "\033[1;31m MISSING 07180.atmos_average.nc, redo Step 2.1\033[0m"
    let mi=mi+1
fi

# ===================================================================================
# 2.5 & 2.8 Make sure d_dz_ucomp d_dz_vcomp is in atmos_average_zstd
# ===================================================================================

if grep -q "07180.atmos_average_zstd.nc" ls.out; then
    MarsPlot.py -i 07180.atmos_average_zstd.nc > inspect.out

    varlist="d_dz_ucomp d_dz_vcomp"

    for vname in $varlist; do
        if grep -q $vname inspect.out; then
            let mi=mi+0
            #echo -e "$vname exists"
        else
            echo -e "\033[1;31m MISSING $vname in 07180.atmos_average_zstd.nc, redo Step 2.8\033[0m"
            let mi=mi+1
        fi
    done
    rm inspect.out
else
    echo -e "\033[1;31m MISSING 07180.atmos_average_zstd.nc, redo Step 2.5\033[0m"
    let mi=mi+1
fi

# ===================================================================================
# 2.6 Make sure d_dz_ucomp d_dz_vcomp are in atmos_diurn_T
# ===================================================================================

if grep -q "07180.atmos_diurn_T.nc" ls.out; then
    MarsPlot.py -i 07180.atmos_diurn_T.nc > inspect.out

    varlist="ts ps temp"

    for vname in $varlist; do
        if grep -q $vname inspect.out; then
            let mi=mi+0
            #echo -e "$vname exists"
        else
            echo -e "\033[1;31m MISSING $vname in 07180.atmos_diurn_T.nc, redo Step 2.6\033[0m"
            let mi=mi+1
        fi
    done
    rm inspect.out
else
    echo -e "\033[1;31m MISSING 07180.atmos_diurn_T.nc, redo Step 2.6\033[0m"
    let mi=mi+1
fi    

# ===================================================================================
# 2.6 Make sure atmos_diurn_T_pstd exists
# ===================================================================================

if grep -q "07180.atmos_diurn_T_pstd.nc" ls.out; then
    let mi=mi+0
    #echo -e "07180.atmos_diurn_T_pstd.nc exists"
else
    echo -e "\033[1;31m MISSING 07180.atmos_diurn_T_pstd.nc, redo Step 2.6\033[0m"
    let mi=mi+1
fi    

# ===================================================================================
# 2.7 Make sure ps ts are in atmos_daily_lpf
# ===================================================================================

if grep -q "07180.atmos_daily_lpf.nc" ls.out; then
    MarsPlot.py -i 07180.atmos_daily_lpf.nc > inspect.out

    varlist="ps ts"

    for vname in $varlist; do
        if grep -q $vname inspect.out; then
            let mi=mi+0
            #echo -e "$vname exists"
        else
            echo -e "\033[1;31m MISSING $vname in 07180.atmos_daily_lpf.nc, redo Step 2.7\033[0m"
            let mi=mi+1
        fi
    done

    if grep -q "Low-pass filter cut-off period  (2)" inspect.out; then
        let mi=mi+0
        #echo -e "Low-pass filter cut-off period is 2"
    else
        echo -e "\033[1;31m ERROR: Low-pass filter cut-off period IS NOT 2, redo Step 2.7\033[0m"
        let mi=mi+1
    fi
    rm inspect.out
else
    echo -e "\033[1;31m MISSING 07180.atmos_daily_lpf.nc, redo Step 2.7\033[0m"
    let mi=mi+1
fi

# ===================================================================================
# 2.9 Make sure dst_mass_col ice_mass_col vap_mass_col are in atmos_daily
# ===================================================================================

if grep -q "07180.atmos_daily.nc" ls.out; then
    MarsPlot.py -i 07180.atmos_daily.nc > inspect.out

    varlist="dst_mass_col ice_mass_col vap_mass_col"

    for vname in $varlist; do
        if grep -q $vname inspect.out; then
            let mi=mi+0
            #echo -e "$vname exists"
        else
            echo -e "\033[1;31m MISSING $vname in 07180.atmos_daily.nc, redo Step 2.9\033[0m"
            let mi=mi+1
        fi
    done
    rm inspect.out
else
    echo -e "\033[1;31m MISSING 07180.atmos_daily.nc, redo Step 2.1\033[0m"
    let mi=mi+1
fi

# Return error message if applicable
if [ $mi -gt 0 ]; then
    :
else
    echo -e "\033[1;32m None.\033[0m"
fi

# ===================================================================================
# cd to ACTIVECLDS
# ===================================================================================

echo -e "\n\033[0;36mfor ACTIVECLDS:\033[0m\n"

cd $pth/CAP_Tutorial/ACTIVECLDS

# ===================================================================================
# 1.1 & 2.1b Make sure all files are present in ACTIVECLDS
# ===================================================================================

ls > ls.out

activefiles="07180.atmos_daily.nc 07180.atmos_average.nc 07180.atmos_diurn.nc 07180.fixed.nc fort.11_0719 fort.11_0720 fort.11_0721 fort.11_0722 fort.11_0723"

for fname in $activefiles; do
    if grep -q $fname ls.out; then
        let ma=ma+0
        #echo -e "$fname exists"
    else
        echo -e "\033[1;31m MISSING $fname, redo Steps 1.1 and 2.1\033[0m"
        let ma=ma+1
    fi
done

if grep -q "07180.atmos_average_pstd.nc" ls.out; then
    let ma=ma+0
    #echo -e "07180.atmos_average_pstd.nc exists"
else
    echo -e "\033[1;31m MISSING 07180.atmos_average_pstd.nc, redo Step 2.2b\033[0m"
    let ma=ma+1
fi   

if grep -q "07180.atmos_average_zstd.nc" ls.out; then
    let ma=ma+0
    #echo -e "07180.atmos_average_zstd.nc exists"
else
    echo -e "\033[1;31m MISSING 07180.atmos_average_zstd.nc, redo Step 2.5b\033[0m"
    let ma=ma+1
fi   


# Return error message if applicable
if [ $ma -gt 0 ]; then
    :
else
    echo -e "\033[1;32m None.\033[0m"
fi




if [ $mi -gt 0 ] || [ $ma -gt 0 ]; then
    echo -e "\n\033[1;31m*** Address the ERROR and/or MISSING messages listed above before continuing to Step 3 ***\033[0m\n"
else
    echo -e "\n\n\033[1;32m*** Congrats! No errors or missing variables were found ***\033[0m\n"
fi

rm $pth/CAP_Tutorial/INERTCLDS/ls.out
rm $pth/CAP_Tutorial/ACTIVECLDS/ls.out

echo -e "\n\033[1;36m********************** Check complete! **********************\033[0m\n"




