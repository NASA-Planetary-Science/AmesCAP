#!/bin/bash

# ATTENTION: Use this script in any shell: bash, csh, tcsh, or zsh.
# Windows Cygwin users can run this too!

# ==========================================================
# Confirm directory hosting CAP_tutorial/ so KEY.sh 
# runs successfully
# ==========================================================

echo -e "\n\033[1;36m********************** Running KEY.sh **********************\033[0m\n"

echo -e "\n\033[0;36m>>> Your current path is:\n\n\033[0m$PWD\033[0;36m\n\n>>> Please type the path to the directory containing CAP_tutorial,\n     i.e. /Users/username:\033[0m\n"

read pth

echo -e "\n\033[0;36m...Looking for CAP_tutorial in ${pth}/... \033[0m\n"

if [ -d "${pth}/CAP_tutorial" ]; then
    cd $pth
    echo -e "\033[1;32mConfirmed! CAP_tutorial is in ${pth}/ \033[0m\n"
else
    echo -e "\033[1;31m *** ERROR: ${pth}/ does NOT contain CAP_tutorial/ *** \033[0m\n"
    exit 1
fi


# ==========================================================
# Create backup directory
# ==========================================================

echo -e "\n\033[0;36m Looking for CAP_tutorial_backup directory... \033[0m"

if [ -d "${pth}/CAP_tutorial_backup" ]; then
    echo -e "\033[0;36m -> /CAP_tutorial_backup exists \033[0m"
else
    echo -e "\033[1;36m -> Creating fort.11 file backup under ${pth}/CAP_tutorial_backup \033[0m"
    cd $pth/
    mkdir CAP_tutorial_backup
    cd CAP_tutorial_backup
    mkdir ACTIVECLDS 
    mkdir INERTCLDS
    cd $pth
fi

# ==========================================================
# Warn the user that this script will delete & re-create
# CAP_tutorial & its subfolders and files.
# ==========================================================

echo -e "\033[0;36m Looking for CAP_tutorial directory \033[0m"

if [ -d "${pth}/CAP_tutorial" ]; then
    echo -e "\033[0;36m -> ${pth}/CAP_tutorial exists \033[0m"

    # If a Custom.in file exists, safely copy it to /CAP_tutorial_backup
    if ls $pth/CAP_tutorial/INERTCLDS/*.in 1> /dev/null 2>&1; then
        cp $pth/CAP_tutorial/INERTCLDS/*.in $pth/CAP_tutorial_backup/INERTCLDS/.
        echo -e "\033[0;36m Safely copying .in file(s) to ${pth}/CAP_tutorial_backup \033[0m"
    else
        :
    fi

    # If a pdf file exists, safely copy it to /CAP_tutorial_backup
    if ls $pth/CAP_tutorial/INERTCLDS/*.pdf 1> /dev/null 2>&1; then
        cp $pth/CAP_tutorial/INERTCLDS/*.pdf $pth/CAP_tutorial_backup/INERTCLDS/.
        echo -e "\033[0;36m Safely copying .pdf file(s) to ${pth}/CAP_tutorial_backup \033[0m"
    else
        :
    fi

    # If any netcdf files exist, safely copy those to /CAP_tutorial_backup
    if ls $pth/CAP_tutorial/INERTCLDS/*.nc 1> /dev/null 2>&1; then
        cp $pth/CAP_tutorial/INERTCLDS/*.nc $pth/CAP_tutorial_backup/INERTCLDS/.
        echo -e "\033[0;36m Safely copying .nc file(s) to ${pth}/CAP_tutorial_backup/INERTCLDS \033[0m"
    else
        :
    fi

    # If any netcdf files exist, safely copy those to /CAP_tutorial_backup
    if ls $pth/CAP_tutorial/ACTIVECLDS/*.nc 1> /dev/null 2>&1; then
        cp $pth/CAP_tutorial/ACTIVECLDS/*.nc $pth/CAP_tutorial_backup/ACTIVECLDS/.
        echo -e "\033[0;36m Safely copying .nc file(s) to ${pth}/CAP_tutorial_backup/ACTIVECLDS \033[0m"
    else
        :
    fi

    # If all fort.11 files present in INERTCLDS, back them up
    if ls $pth/CAP_tutorial/INERTCLDS/fort.11_0719 1> /dev/null 2>&1; then
        if ls $pth/CAP_tutorial/INERTCLDS/fort.11_0720 1> /dev/null 2>&1; then
            if ls $pth/CAP_tutorial/INERTCLDS/fort.11_0721 1> /dev/null 2>&1; then
                if ls $pth/CAP_tutorial/INERTCLDS/fort.11_0722 1> /dev/null 2>&1; then
                    if ls $pth/CAP_tutorial/INERTCLDS/fort.11_0723 1> /dev/null 2>&1; then
                        echo -e "\033[0;36m Safely copying fort.11 file(s) to /CAP_tutorial_backup/INERTCLDS \033[0m"
                        cp $pth/CAP_tutorial/INERTCLDS/fort.11_* $pth/CAP_tutorial_backup/INERTCLDS/.
                    else
                        :
                    fi
                else
                    :
                fi
            else
                :
            fi
        else
            :
        fi
    else
        :
    fi

        # If all fort.11 files present in ACTIVECLDS, back them up
    if ls $pth/CAP_tutorial/ACTIVECLDS/fort.11_0719 1> /dev/null 2>&1; then
        if ls $pth/CAP_tutorial/ACTIVECLDS/fort.11_0720 1> /dev/null 2>&1; then
            if ls $pth/CAP_tutorial/ACTIVECLDS/fort.11_0721 1> /dev/null 2>&1; then
                if ls $pth/CAP_tutorial/ACTIVECLDS/fort.11_0722 1> /dev/null 2>&1; then
                    if ls $pth/CAP_tutorial/ACTIVECLDS/fort.11_0723 1> /dev/null 2>&1; then
                        echo -e "\033[0;36m Safely copying fort.11 file(s) to ${pth}/CAP_tutorial_backup/ACTIVECLDS \033[0m"
                        cp $pth/CAP_tutorial/ACTIVECLDS/fort.11_* $pth/CAP_tutorial_backup/ACTIVECLDS/.
                    else
                        :
                    fi
                else
                    :
                fi
            else
                :
            fi
        else
            :
        fi
    else
        :
    fi

    echo -e "\n\033[0;31m *** Deleting /CAP_tutorial & subdirectories *** \033[0m\n"
    # Remove CAP_tutorial & all subdirectories, files
    rm -r $pth/CAP_tutorial
else
    echo -e "\033[0;36m -> /CAP_tutorial does not exist \033[0m"
fi

# ==========================================================
# Source & update amesGCM3
# ==========================================================

#source ~/amesGCM3/bin/activate
echo -e "\033[0;36m -> Updating the pipeline to the most recent version \033[0m"
pip install git+https://github.com/alex-kling/amesgcm.git --upgrade


# ==========================================================
# 1. Retrieve Data
# ==========================================================

echo -e "\n\033[0;36m -> Recreating /CAP_tutorial & subdirectories \033[0m\n"

cd $pth/
mkdir CAP_tutorial
cd CAP_tutorial
mkdir ACTIVECLDS 
mkdir INERTCLDS


cd INERTCLDS


echo -e "\n\033[1;36m 1. Retrieving fort.11 files from INERTCLDS/ in the data portal \033[0m"

if ls $pth/CAP_tutorial_backup/INERTCLDS/fort.11_0719 1> /dev/null 2>&1; then
    echo -e "\033[0;36m Copying over fort.11 files from CAP_tutorial_backup/ \033[0m\n"
    cp $pth/CAP_tutorial_backup/INERTCLDS/fort* .
else
    echo -e "\033[0;36m -> If this appears stuck, check whether the files on the data portal are available at: \nhttps://data.nas.nasa.gov/mcmc/data_legacygcm.php \033[0m"
    echo -e "\033[0;36m and if data is unavailable on the portal, try again later. \033[0m\n"
    MarsPull.py -id INERTCLDS -ls 255 285
    # Downloads fort.11_0719 through fort.11_0723
    echo -e "\033[0;36m -> Creating backup under ~/CAP_tutorial_backup/INERTCLDS \033[0m\n"
    cp fort* $pth/CAP_tutorial_backup/INERTCLDS/.
fi


cd ../ACTIVECLDS


echo -e "\n\033[1;36m 1.b Retrieving fort.11 files from ACTIVECLDS/ in the data portal \033[0m"

if ls $pth/CAP_tutorial_backup/ACTIVECLDS/fort.11_0719 1> /dev/null 2>&1; then
    echo -e "\033[0;36m Copying over fort.11 files from CAP_tutorial_backup/ \033[0m\n"
    cp $pth/CAP_tutorial_backup/ACTIVECLDS/fort* .
else
    echo -e "\033[0;36m -> If this appears stuck, check whether the files on the data portal are available at: \nhttps://data.nas.nasa.gov/mcmc/data_legacygcm.php \033[0m"
    echo -e "\033[0;36m and if data is unavailable on the portal, try again later. \033[0m\n"
    MarsPull.py -id ACTIVECLDS -ls 255 285
    # Downloads fort.11_0719 through fort.11_0723
    echo -e "\033[0;36m -> Creating backup under ~/CAP_tutorial_backup/ACTIVECLDS \033[0m\n"
    cp fort* $pth/CAP_tutorial_backup/ACTIVECLDS/.
fi

# ==========================================================
# If user had a Custom.in file, move it back to CAP_tutorial/INERTCLDS
# ==========================================================

cd

if ls $pth/CAP_tutorial_backup/INERTCLDS/*.in 1> /dev/null 2>&1; then
    cp $pth/CAP_tutorial_backup/INERTCLDS/*.in $pth/CAP_tutorial/INERTCLDS/.
    rm $pth/CAP_tutorial_backup/INERTCLDS/*.in
    echo -e "\n\033[0;36m Safely moving .in file(s) back into /CAP_tutorial/INERTCLDS \033[0m"
else
    :
fi

# ==========================================================
# If user had a PDF file, move it back to CAP_tutorial/INERTCLDS
# ==========================================================

if ls $pth/CAP_tutorial_backup/INERTCLDS/*.pdf 1> /dev/null 2>&1; then
    cp $pth/CAP_tutorial_backup/INERTCLDS/*.pdf $pth/CAP_tutorial/INERTCLDS/.
    rm $pth/CAP_tutorial_backup/INERTCLDS/*.pdf
    echo -e "\033[0;36m Safely moving .pdf file(s) back into /CAP_tutorial/INERTCLDS \033[0m"
else
    :
fi




# ==========================================================
# 2. File Manipulations
# ==========================================================

# 2.1 Convert fort.11 to netcdf
echo -e "\n\033[1;36m 2.1 Converting fort.11 to netcdf \033[0m\n"
cd $pth/CAP_tutorial/INERTCLDS
MarsFiles.py fort.11_* -fv3 fixed average daily diurn

# Merge
MarsFiles.py *fixed.nc -c
MarsFiles.py *daily.nc -c
MarsFiles.py *diurn.nc -c
MarsFiles.py *average.nc -c

# 2.2 Interpolate atmos_average to pstd
echo -e "\n\033[1;36m 2.2 Interpolating atmos_average to pstd \033[0m\n"
MarsInterp.py 07180.atmos_average.nc -t pstd

# 2.3 Add msf to atmos_averaage_pstd
echo -e "\n\033[1;36m 2.3 Adding msf to atmos_averaage_pstd \033[0m\n"
MarsVars.py 07180.atmos_average_pstd.nc -add msf

# 2.4 Add rho, zfull to atmos_average
echo -e "\n\033[1;36m 2.4 Adding rho, zfull to atmos_average \033[0m\n"
MarsVars.py 07180.atmos_average.nc -add rho zfull

# 2.5 Interpolate atmos_average to zstd
echo -e "\n\033[1;36m 2.5 Interpolating atmos_average to zstd \033[0m\n"
MarsInterp.py 07180.atmos_average.nc -t zstd

# 2.6 Time-shift the diurn file, then pressure interpolate
echo -e "\n\033[1;36m 2.6 Time-shifting and pressure-interpolating the diurn file \033[0m\n"
MarsFiles.py 07180.atmos_diurn.nc -t --include ts ps temp
MarsInterp.py 07180.atmos_diurn_T.nc -t pstd

# 2.7 Apply a LPF to ps and ts in atmos_daily
echo -e "\n\033[1;36m 2.7 Applying a LPF to ps and ts in atmos_daily \033[0m\n"
MarsFiles.py 07180.atmos_daily.nc -lpf 2 -include ps ts

# 2.8 Estimate the magnitude of the wind shear
echo -e "\n\033[1;36m 2.8 Estimating the magnitude of the wind shear \033[0m\n"
MarsVars.py 07180.atmos_average_zstd.nc -zdiff ucomp vcomp

# 2.9 Column-integrated dst_mass, vap_mass, ice_mass in atmos_daily
echo -e "\n\033[1;36m 2.9 Column-integrating dst_mass, vap_mass, ice_mass in atmos_daily \033[0m\n"
MarsVars.py 07180.atmos_daily.nc -col dst_mass ice_mass vap_mass

# 2.10 Display values `pfull`, min, mean, max near-surface `temp` over the globe
echo -e "\n\033[1;36m 2.10 Displaying values pfull, min, mean, max near-surface temp over the globe \033[0m\n"
MarsPlot.py -i 07180.atmos_average.nc -dump pfull
MarsPlot.py -i 07180.atmos_average.nc -dump 'pfull[-1]'
MarsPlot.py -i 07180.atmos_average.nc -stat 'temp[:,-1,:,:]'


# ==========================================================
# REPEAT 2.1, 2.2, 2.5 for RAC
# ==========================================================
echo -e "\n\033[1;36m -> Repeating 2.1, 2.2, and 2.5 for ACTIVECLDS/ \033[0m\n"

# 2.1b Convert fort.11 to netcdf
echo -e "\n\033[1;36m 2.1b Converting fort.11 to netcdf \033[0m\n"
cd $pth/CAP_tutorial/ACTIVECLDS
MarsFiles.py fort.11_* -fv3 fixed average daily diurn

# Merge
MarsFiles.py *fixed.nc -c
MarsFiles.py *daily.nc -c
MarsFiles.py *diurn.nc -c
MarsFiles.py *average.nc -c

# 2.2b Interpolate atmos_average to pstd
echo -e "\n\033[1;36m 2.2b Interpolating atmos_average to pstd \033[0m\n"
MarsInterp.py 07180.atmos_average.nc -t pstd

# 2.5b Interpolate atmos_average to zstd
echo -e "\n\033[1;36m 2.5b Interpolating atmos_average to zstd \033[0m\n"
MarsInterp.py 07180.atmos_average.nc -t zstd



echo -e "\n\033[1;35m       REMINDER: There is a backup of any netcdf file(s) in /CAP_tutorial that you previously created in /CAP_tutorial_backup.\033[0m\n"



# ==========================================================
# 3. Plotting
# ==========================================================
cd $pth/CAP_tutorial/INERTCLDS

if [ -f "KEY.in" ]; then
    echo -e "\n\033[1;36m 3. Plotting Results \033[0m\n"
    echo -e "\n\033[0;36m -> Running MarsPlot.py with the KEY.in template.\033[0m\n"
    MarsPlot.py KEY.in
    echo -e "\n\033[0;36m -> Compare KEY.pdf to the PDFs you created \033[0m\n"
else
    echo -e "\n\033[0;36m If you want to run MarsPlot.py with the answer key, move KEY.in to the INERTCLDS/ directory. \033[0m\n"
fi

echo -e "\n\033[1;36m********************** KEY.sh complete! **********************\033[0m\n"


